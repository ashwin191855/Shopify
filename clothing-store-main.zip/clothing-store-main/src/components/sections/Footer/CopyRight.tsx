const CopyRight = () => {
  return (
    <p className="text-center text-darkPurple">
      Copyright © 2023 Rashid Shamloo
      <br />
      All Rights Reserved
    </p>
  );
};

export default CopyRight;
