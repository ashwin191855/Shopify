export const colors = {
  Black: '#000000',
  White: '#ffffff',
  'Off White': '#faf9f6',
  Natural: '#f9f8ec',
  'Light Gray': '#d3d3d3',
  'Medium Gray': '#8e99a3',
  'Light Blue': '#add8e6',
  Cobalt: '#0047AB',
  Navy: '#000080',
  'Light Pink': '#ffb6c1',
  Red: 'red',
  Kelly: '#4cbb17',
  Green: 'green',
  Olive: '#808000',
  Beige: '#f5f5dc',
  Moca: '#967969',
  'Dark Brown': '#5c4033'
};
